---
created:
  - "2025-03-06 09:34"
---
>[!info] Contact 
Nom Prénom : Monnier Matthieu
Email : matthieumm444444@gmail.com
Email Scolaire : matthieu.monnier@ecoles-epsi.net

---
- 2025-03-06 09:34 - Création initiale
---

> [!info] Sommaire
> ```table-of-contents
> ```

---
# Schéma Base de donnée 
![[Projet solution web BDD.drawio 2.png]]
# Monter / configurer la vm qui acceuillera le site
- j'utilise un proxmox à la maison pour créer la vm
- j'y installe ensuite apache2, php, mariadb-server, git
- on y modifie les vhost pour ajouter un nouveau site (ici bijouterie-chimere)
- j'ai ensuite installé phpmyadmin en suivant ce tuto : https://phoenixnap.com/kb/how-to-install-phpmyadmin-on-debian
- et recréé les tables du schéma
